import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { rmSync, mkdirSync, existsSync, writeFileSync, chmodSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { createActor } from "xstate";
import { createBuckMachine } from "../machine.js";
import { buildQueue } from "../queue-builder.js";
import { verifyResult } from "../verify-result.js";
import { readProjection } from "../persistence.js";
import { runWorker } from "../worker.js";

// ---------------------------------------------------------------------------
// SDK mock — hoisted so sdk-worker.ts (imported via worker.ts) gets the fake
// ---------------------------------------------------------------------------

vi.mock("@mariozechner/pi-coding-agent", () => ({
  createAgentSession: vi.fn(),
  SessionManager: { inMemory: vi.fn(() => ({})) },
  SettingsManager: { inMemory: vi.fn(() => ({})) },
}));

import { createAgentSession } from "@mariozechner/pi-coding-agent";


const TEST_ROOT = join("/tmp", "bflow-test-" + Date.now());

async function waitFor(
  predicate: () => boolean,
  timeoutMs = 3_000,
): Promise<void> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (predicate()) return;
    await new Promise((r) => setTimeout(r, 25));
  }
  throw new Error("Timed out waiting for condition");
}

function installFakePi(root: string): () => void {
  const binDir = join(root, "bin");
  mkdirSync(binDir, { recursive: true });
  const fakePiPath = join(binDir, "pi");
  writeFileSync(
    fakePiPath,
    `#!/usr/bin/env node
const fs = require('node:fs');
const promptArg = process.argv.find((arg) => arg.startsWith('@'));
if (!promptArg) process.exit(2);
const prompt = fs.readFileSync(promptArg.slice(1), 'utf8');
const resultFile = prompt.split('Write a result file to: ')[1]?.split('\\n')[0]?.trim();
if (!resultFile) process.exit(3);
fs.writeFileSync(resultFile, \`---\nchunk_id: fake\nchunk_type: phase\nstatus: completed\nstarted_at: 2026-05-09T00:00:00Z\ncompleted_at: 2026-05-09T00:00:01Z\nworker_attempt: 1\nmodel_used: fake\nchanged_files: []\nacceptance_criteria_met: [all]\nacceptance_criteria_missed: []\nwarnings: []\n---\n\n# Worker Result\n\nDone.\n\`);
`,
    "utf-8",
  );
  chmodSync(fakePiPath, 0o755);
  const originalPath = process.env.PATH ?? "";
  process.env.PATH = `${binDir}:${originalPath}`;
  return () => {
    process.env.PATH = originalPath;
  };
}

describe("b-flow integration", () => {
  beforeEach(() => {
    if (existsSync(TEST_ROOT)) rmSync(TEST_ROOT, { recursive: true });
    mkdirSync(TEST_ROOT, { recursive: true });
  });

  afterEach(() => {
    if (existsSync(TEST_ROOT)) rmSync(TEST_ROOT, { recursive: true });
  });

  it("happy path: start transitions from idle", async () => {
    const machine = createBuckMachine(TEST_ROOT);
    const actor = createActor(machine);
    actor.start();

    actor.send({ type: "START", goal: "test goal" });
    await new Promise((r) => setTimeout(r, 100));

    const snapshot = actor.getSnapshot();
    expect(
      ["recovering", "planning", "decomposing", "blocked"].includes(String(snapshot.value)),
    ).toBe(true);
    expect(snapshot.context.projection.goal).toBe("test goal");

    actor.stop();
  });

  it("persistence writes projection after transitions", async () => {
    const machine = createBuckMachine(TEST_ROOT);
    const actor = createActor(machine);
    actor.start();

    actor.send({ type: "START", goal: "persist test" });
    await new Promise((r) => setTimeout(r, 200));

    const projection = readProjection(TEST_ROOT);
    expect(projection).not.toBeNull();
    expect(projection?.goal).toBe("persist test");
    expect(projection?.currentState).not.toBe("idle");

    actor.stop();
  });

  it("continue executes queued phase through worker subprocess", async () => {
    const restorePath = installFakePi(TEST_ROOT);
    try {
      const subject = "2026-05-08.test-subject";
      const subjectDir = join(TEST_ROOT, ".context", subject);
      mkdirSync(subjectDir, { recursive: true });

      writeFileSync(
        join(subjectDir, "plan-test-phases.md"),
        "---\nstatus: active\nformat: discrete\n---\n# Phases\n",
      );
      writeFileSync(
        join(subjectDir, "phase-1-test.md"),
        "---\nstatus: active\ndifficulty: easy\n---\n# Phase 1\n",
      );

      const machine = createBuckMachine(TEST_ROOT);
      const actor = createActor(machine);
      actor.start();

      actor.send({ type: "START", goal: "execute queued phase" });
      // Active phase routes directly from planning to executingChunks
      await waitFor(() => String(actor.getSnapshot().value) === "executingChunks");
      await waitFor(() => String(actor.getSnapshot().value) === "reviewing");

      const snapshot = actor.getSnapshot();
      expect(snapshot.context.subject).toBe(subject);
      expect(snapshot.context.projection.subject).toBe(subject);
      expect(snapshot.context.projection.queue.length).toBe(1);
      expect(snapshot.context.projection.queue[0].status).toBe("completed");

      const resultsDir = join(subjectDir, "worker-results");
      expect(readdirSync(resultsDir).some((f) => f.endsWith(".md"))).toBe(true);

      actor.stop();
    } finally {
      restorePath();
    }
  });

  it("runWorker dispatches to SDK worker when BFLOW_USE_SDK_WORKER=1", async () => {
    vi.mocked(createAgentSession).mockResolvedValue({
      session: {
        prompt: vi.fn().mockResolvedValue(undefined),
        subscribe: vi.fn(),
        abort: vi.fn().mockResolvedValue(undefined),
        dispose: vi.fn(),
        messages: [{ role: "assistant", content: "Done." }],
      } as any,
      extensionsResult: { extensions: [], errors: [], runtime: {} as any },
    });

    process.env.BFLOW_USE_SDK_WORKER = "1";
    try {
      const result = await runWorker(
        {
          id: "sdk-integration-test",
          type: "phase",
          path: join(TEST_ROOT, "chunks", "sdk-test.md"),
          status: "pending",
          workerAttempts: 0,
        },
        { projectRoot: TEST_ROOT, subject: null, goal: "SDK integration test", timeoutMs: 5_000 },
      );

      expect(result.type).toBe("WORKER_COMPLETED");
      expect(createAgentSession).toHaveBeenCalled();
    } finally {
      delete process.env.BFLOW_USE_SDK_WORKER;
    }
  });

  it("sdk worker failure surfaces as WORKER_FAILED", async () => {
    vi.mocked(createAgentSession).mockRejectedValue(new Error("SDK connection failed"));

    process.env.BFLOW_USE_SDK_WORKER = "1";
    try {
      const result = await runWorker(
        {
          id: "sdk-failure-test",
          type: "phase",
          path: join(TEST_ROOT, "chunks", "sdk-fail.md"),
          status: "pending",
          workerAttempts: 0,
        },
        { projectRoot: TEST_ROOT, subject: null, goal: "SDK failure test", timeoutMs: 5_000 },
      );

      expect(result.type).toBe("WORKER_FAILED");
      expect(result.error).toContain("SDK connection failed");
    } finally {
      delete process.env.BFLOW_USE_SDK_WORKER;
    }
  });

  it("falls back to subprocess when BFLOW_USE_SDK_WORKER is unset", async () => {
    const restorePath = installFakePi(TEST_ROOT);
    delete process.env.BFLOW_USE_SDK_WORKER;
    try {
      const { runWorker } = await import("../worker.js");
      const result = await runWorker(
        {
          id: "subprocess-fallback-test",
          type: "phase",
          path: join(TEST_ROOT, "chunks", "fallback.md"),
          status: "pending",
          workerAttempts: 0,
        },
        { projectRoot: TEST_ROOT, subject: null, goal: "Fallback test", timeoutMs: 5_000 },
      );

      expect(result.type).toBe("WORKER_COMPLETED");
      expect(result.resultFile).toBeDefined();
    } finally {
      restorePath();
    }
  });

  it("queue builder finds phases in subject folder", () => {
    const subjectDir = join(TEST_ROOT, ".context", "2026-05-08.test-subject");
    mkdirSync(subjectDir, { recursive: true });

    writeFileSync(
      join(subjectDir, "phase-1-types.md"),
      "---\nstatus: pending\ndifficulty: easy\n---\n# Phase 1\n",
    );
    writeFileSync(
      join(subjectDir, "phase-2-machine.md"),
      "---\nstatus: pending\ndifficulty: medium\n---\n# Phase 2\n",
    );
    writeFileSync(
      join(subjectDir, "phase-3-worker.md"),
      "---\nstatus: completed\n---\n# Phase 3\n",
    );

    const queue = buildQueue(TEST_ROOT, "2026-05-08.test-subject");
    expect(queue.length).toBe(2);
    expect(queue[0].id).toBe("phase-phase-1-types");
    expect(queue[0].difficulty).toBe("easy");
    expect(queue[1].difficulty).toBe("medium");
  });

  it("queue builder finds tasks.md unchecked items", () => {
    const subjectDir = join(TEST_ROOT, ".context", "2026-05-08.test-subject");
    mkdirSync(subjectDir, { recursive: true });

    writeFileSync(
      join(subjectDir, "tasks.md"),
      "# Tasks\n\n- [x] Done task\n- [ ] Todo 1\n- [ ] Todo 2\n",
    );

    const queue = buildQueue(TEST_ROOT, "2026-05-08.test-subject");
    const tasks = queue.filter((q) => q.type === "task");
    expect(tasks.length).toBe(2);
  });

  it("verifyResult parses completed worker result", () => {
    const resultFile = join(TEST_ROOT, "result.md");
    writeFileSync(
      resultFile,
      "---\nchunk_id: test-1\nchunk_type: phase\nstatus: completed\nstarted_at: 2026-05-09T00:00:00Z\ncompleted_at: 2026-05-09T00:01:00Z\nworker_attempt: 1\nmodel_used: test\nchanged_files: [file.ts]\nacceptance_criteria_met: [all]\nacceptance_criteria_missed: []\nwarnings: []\n---\n\n# Worker Result\n\n## Summary\nDone.\n",
    );

    const result = verifyResult(resultFile);
    expect(result.type).toBe("CHUNK_VERIFIED");
    expect(result.status).toBe("completed");
  });

  it("verifyResult detects warnings", () => {
    const resultFile = join(TEST_ROOT, "result.md");
    writeFileSync(
      resultFile,
      "---\nchunk_id: test-1\nchunk_type: phase\nstatus: completed\nwarnings: [minor issue]\nacceptance_criteria_missed: [edge case]\n---\n",
    );

    const result = verifyResult(resultFile);
    expect(result.type).toBe("CHUNK_WARNINGS");
    expect(result.status).toBe("completed_with_warnings");
  });

  it("verifyResult detects blocked", () => {
    const resultFile = join(TEST_ROOT, "result.md");
    writeFileSync(
      resultFile,
      "---\nchunk_id: test-1\nchunk_type: phase\nstatus: blocked\nblock_reason: needs user input\n---\n",
    );

    const result = verifyResult(resultFile);
    expect(result.type).toBe("CHUNK_BLOCKED");
    expect(result.status).toBe("blocked");
  });

  it("machine defines all required states", () => {
    const machine = createBuckMachine(TEST_ROOT);
    expect(machine).toBeTruthy();
    expect(machine.config.id).toBe("buck-flow");
    const states = Object.keys(machine.config.states ?? {});
    expect(states).toContain("idle");
    expect(states).toContain("done");
    expect(states).toContain("aborted");
    expect(states).toContain("executingChunks");
  });
});
