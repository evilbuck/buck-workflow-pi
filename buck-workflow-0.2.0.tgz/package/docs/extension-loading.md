# Extension Loading: Pi vs Oh My Pi

## Terminology

| Concept | Pi | Oh My Pi |
|---------|----|-----------|
| Config file | `~/.pi/agent/settings.json` | `~/.omp/agent/config.yml` |
| Config key | `packages: [...]` | `extensions: [...]` |
| Unit of install | Package | Plugin |
| Install command | `pi install` | `omp install` |
| Managed by chezmoi | `dot_pi/agent/settings.local.jsonc` | `dot_omp/private_agent/config.local.yml` |

**Packages (Pi) and plugins (OMP) are the same concept.** OMP's `extensions` list can load Pi packages directly — it's a superset of the Pi package resolution logic.

## How Pi Loads Packages

Pi reads `settings.json` → `packages`. Each entry is a source string or a filter object:

```jsonc
"packages": [
  "npm:pi-mcp-adapter",                          // npm package
  "git:github.com/tmustier/pi-extensions",       // git repo
  "../../projects/development_tools/buck-workflow-pi",  // local path
  {
    // Filter object — load only specific resources
    "source": "../../projects/development_tools/buck-workflow-pi",
    "extensions": ["+extensions/index.ts"],
    "skills": ["+skills/b-build/", "+skills/b-plan/"],
    "prompts": ["+prompts/b-build.md"]
  }
]
```

Pi auto-discovers from each package path:

| Directory | What it provides |
|-----------|-----------------|
| `extensions/` | Runtime extensions (commands, hooks, tools) |
| `skills/` | Skills (`skills/<name>/SKILL.md`) |
| `prompts/` | Prompt templates (`prompts/<name>.md`) |
| `themes/` | Theme files |

Filter objects use `+` to include and `-` to exclude specific paths. Without a filter object, Pi loads everything it discovers.

## How OMP Loads Packages/Plugins

OMP reads `config.yml` → `extensions`. Each entry is a path (string):

```yaml
extensions:
  - ~/.pi/agent/extensions/omarchy-system-theme.ts  # single .ts file
  - ~/.pi/agent/git/github.com/tmustier/pi-extensions/agent-guidance  # directory
  - ~/projects/development_tools/buck-workflow-pi  # local project package
```

OMP resolves each path using the same rules as Pi:

| Path type | Resolution |
|-----------|-----------|
| Single file (`*.ts`, `*.js`) | Loaded as one extension module |
| Directory with `plugin.json` | Reads manifest for entry points (OMP plugin format) |
| Directory with `package.json` | Reads `omp.extensions` / `pi.extensions` manifest key |
| Directory with `index.ts` | Loaded as the package entry |
| Directory with `extensions/`, `skills/`, `prompts/`, `themes/` subdirs | Auto-discovers each |

## The `commands/` vs `prompts/` Discrepancy

OMP's `omp-plugins` provider reads `commands/` for **slash commands** (`/foo`) and `prompts/` for **reusable prompt templates** (invoked via tool). Pi inverts this: it reads `prompts/*.md` and exposes them as slash commands. The two runtimes use the same physical content for two different registration surfaces.

```
my-plugin/                       my-package/
  plugin.json                      package.json
  commands/<name>.md  ←slash       prompts/<name>.md  ←slash
  prompts/<name>.md  ←template     (no `commands/`)
```

For OMP-installed plugins with a `plugin.json`, the manifest can list `commands` as a path or glob. OMP's `omp.commands` manifest entry resolves directories only via `index.{ts,js,mjs,cjs}` — a directory of `*.md` files is **not** resolvable through that key. For Pi-style packages, `commands/` is auto-discovered from the package root.

**This package resolves the discrepancy with a `commands/` mirror.** `prompts/*.md` is the single source of truth. Every `commands/*.md` entry is a symlink (`commands/b-plan.md` → `../prompts/b-plan.md`) so OMP's `omp-plugins` provider picks them up as slash commands without duplicating content. The mirror is test-enforced (`scripts/commands-mirror.test.ts`) with **zero physical-file exceptions** — adding a new prompt is one `ln -s` away, and forgetting it fails CI.

### Cross-Platform Slash Command Pattern

```
buck-workflow-pi/
  prompts/                       # source of truth (Pi reads these as slash commands)
    b-plan.md
    b-build.md
    ...
  commands/                      # symlink mirror (OMP reads these as slash commands)
    b-plan.md    -> ../prompts/b-plan.md
    b-build.md   -> ../prompts/b-build.md
    ...
```

To add a new slash command for both runtimes:

```bash
# 1. Write the prompt body in prompts/ (Pi auto-discovers)
$EDITOR prompts/b-newcommand.md

# 2. Mirror it into commands/ for OMP discovery
ln -s ../prompts/b-newcommand.md commands/b-newcommand.md
```

**Mirror contract (healed 2026-09-18):** every `commands/*.md` entry is a symlink to `../prompts/<name>.md`; there are no physical-file exceptions.

- **Diverged twins** (formerly `b-pr.md`, `b-pr-review-2-issues.md`, `b-commit-improved.md`, `b-save-improved.md`): the thin skill-loader stub body won and now lives in `prompts/` — the full duplicate prompt bodies had gone stale against their `SKILL.md` counterparts, and the `*-improved` stubs document the extension-vs-skill fallback path that matters on both runtimes.
- **OMP-only commands** (formerly `b-kamal-release.md`, `b-pr-improved.md`, `git-clean-orphans.md`, `product-tour.md`): their bodies moved verbatim into `prompts/`, so Pi registers them as slash commands too.

Drift is now mechanically prevented: `scripts/commands-mirror.test.ts` (part of `npm test`) derives the expected mirror from `prompts/` and fails on any missing symlink, physical twin, or undeclared extra.

## Current State of buck-workflow-pi

```
buck-workflow-pi/
  package.json              # buck-workflow
                            # `pi` and `omp` keys: extensions entry point
  extensions/
    index.ts                # Entry — default export wires everything marked (wired)
    tps-tracker.ts          # (wired) Token-per-second tracking
    omp-models.ts           # (wired, library) OMP role→model catalog + mappingFromOmpRoles
    plan-artifact.ts        # (wired) opt-in plan-mode → .context/ bridge (turn_end hook)
    extension-activity.ts   # (wired, library) shared live-activity progress helper
    subprocess.ts           # (library) shared subprocess helpers
    b-pr-improved/          # (wired) deterministic /b-pr-improved command
    b-commit-improved/      # (wired) deterministic /b-commit-improved command
    b-save-improved/        # (wired) deterministic /b-save-improved command
    b-kamal-release/        # (wired) deterministic /b-kamal-release command
    b-flow/                 # (unwired) b-flow orchestration subsystem
    b-grill-auto/           # (unwired) b-grill-auto RPC subsystem
    grill-me-dialog.ts      # (unwired) grill-me dialog
    tmux-window-status.ts   # (unwired) tmux window status
    *.test.ts               # Tests for extension behavior
  skills/
    b-build/SKILL.md
    b-plan/SKILL.md
    b-research/SKILL.md
    b-save/SKILL.md         # b-save as pure skill (no extension backing)
    ... (64 skill directories total)
  prompts/                  # source of truth for slash command bodies
    b-build.md
    b-plan.md
    b-save.md               # b-save prompt (reads state file directly)
    b-commit.md             # b-commit prompt (git-commit skill wrapper)
    ... (43 prompt files total)
  commands/                 # symlink mirror so OMP discovers slash commands
    b-build.md    -> ../prompts/b-build.md
    b-save.md     -> ../prompts/b-save.md
    b-commit.md   -> ../prompts/b-commit.md
    ... (one symlink per prompts/*.md entry — 1:1, test-enforced)

`package.json` declares both `pi` and `omp` keys. The `pi` key lists `extensions`, `prompts`, and `skills` because Pi's filter-object schema exposes them as first-class. The `omp` key lists only `extensions` because OMP's `omp-plugins` provider auto-discovers `skills/`, `commands/`, `prompts/`, and the other sibling directories directly from the package root — duplicating them in the `omp` manifest would be redundant and brittle. (JSON disallows comments, so this rationale lives here rather than in `package.json`.)

### Extension contents

`extensions/index.ts` is the single manifest entry; its default export composes every wired subsystem:

1. **Model auto-switch** — Reads `buckModelMapping` from Pi settings (or OMP role mapping via `extensions/omp-models.ts`), inspects the active phase difficulty in phased plans, and auto-switches the model on `/b-build`, `/b-build-hard`, `/b-iterate`, and `/b-review`. Switches back to the original model on `agent_end`. Includes a TUI model picker for initial setup.
2. **TPS tracker** (`tps-tracker.ts`) — Token-per-second tracking during model generation.
3. **`/b-pr-improved`** (`b-pr-improved/`) — deterministic, code-driven PR creation.
4. **`/b-commit-improved`** (`b-commit-improved/`) — deterministic Conventional Commit.
5. **`/b-save-improved`** (`b-save-improved/`) — deterministic session checkpoint (preflight → scribe/auditor → apply).
6. **`/b-kamal-release`** (`b-kamal-release/`) — deterministic kamal release pipeline.
7. **Plan-artifact bridge** (`plan-artifact.ts`) — opt-in (`buckPlanArtifact.enabled` / `BUCK_PLAN_ARTIFACT=1`) `turn_end` hook that persists an exited OMP plan-mode plan into the `.context/` subject-folder convention.

`extension-activity.ts` (live progress UI) and `subprocess.ts` are shared libraries used by the deterministic commands. The four deterministic commands fall back to their skill counterparts (`b-pr`, `git-commit-improved`, `b-save-improved`) when the extension is not loaded — see the real-file command stubs under `commands/`.

Everything older (b-mode, b-restrict, plan mode write guard, b-save command, b-flow, b-grill-auto extension command, session state machine, tmux status) has been removed or left unwired. `/b-save` proper remains a pure skill + prompt — the LLM reads `.context/workflow/current-session.json` directly instead of receiving injected state from an extension handler. See `skills/b-save/SKILL.md` for details.


## Sub-directory auto-discovery in OMP

OMP's `omp-plugins` provider (`packages/coding-agent/src/discovery/omp-plugins.ts`) walks each registered package root and reads these sibling directories unconditionally:

| Sibling | Loaded as | Notes |
|---------|-----------|-------|
| `skills/` | `Skill` items | `skills/<name>/SKILL.md` |
| `commands/` | `SlashCommand` items | `commands/<name>.md` — registers `/foo` |
| `prompts/` | `Prompt` items | `prompts/<name>.md` — reusable prompt template, not a slash command |
| `rules/` | `Rule` items | `rules/<name>.md` |
| `hooks/pre/` | Pre-run hooks | `hooks/pre/<name>.{ts,js}` |
| `hooks/post/` | Post-run hooks | `hooks/post/<name>.{ts,js}` |
| `tools/` | `Tool` items | `tools/<name>.{ts,js}` |
| `.mcp.json` / `mcp.json` | MCP server config | JSON manifest of `mcpServers` |

This provider is independent of the `omp` field in `package.json`. The `omp` field is read by the extension loader for `extensions`/`themes`/`skills` arrays; the `omp-plugins` provider handles the rest by directory walk.

## Loading in Each Environment

### Pi (`~/.pi/agent/settings.json`)

```jsonc
{
  "source": "../../projects/development_tools/buck-workflow-pi",
  "extensions": ["+extensions/index.ts"],
  "skills": [
    "+skills/b-blueprint/", "+skills/b-brainstorm/", "+skills/b-build/",
    "+skills/b-explore/", "+skills/b-grill/", "+skills/b-grill-auto/",
    "+skills/b-grill-me/", "+skills/b-grill-with-docs/", "+skills/b-iterate/",
    "+skills/b-phase/", "+skills/b-plan/", "+skills/b-present/",
    "+skills/b-research/", "+skills/b-review/", "+skills/crawl4ai/",
    "+skills/git-commit/", "+skills/pi-rpc/", "+skills/run-in-idle-pane/",
    "+skills/_shared/"
  ],
  "prompts": [
    "+prompts/b-brainstorm.md", "+prompts/b-build-hard.md",
    "+prompts/b-build.md", "+prompts/b-explore.md",
    "+prompts/b-grill-me.md", "+prompts/b-grill-with-docs.md",
    "+prompts/b-iterate.md", "+prompts/b-plan.md",
    "+prompts/b-present.md", "+prompts/b-research.md",
    "+prompts/b-review.md", "+prompts/b-commit.md"
  ]
}
```

Pi requires explicit filter objects because its `packages` config supports `+`/`-` filtering.

> The lists above are an **excerpted example**, not the current inventory — the package ships 60+ skills and 40 prompts. List only what you actually want loaded, or drop the filter keys to load everything.

### OMP (`~/.omp/agent/config.yml`)

```yaml
extensions:
  - ~/projects/development_tools/buck-workflow-pi
```

OMP auto-discovers `extensions/`, `skills/`, `prompts/`, and `commands/` from the path. No filtering needed — it loads everything it finds. The `commands/` mirror makes this package's slash commands visible to OMP the same way `prompts/` makes them visible to Pi.

## Debugging Load Failures

### Check what loaded

```
omp list                              # installed plugins
omp -p '/extensions'                  # every surface that resolved this session
pi list                               # Pi equivalent
```

### Check logs

```
omp logs                              # OMP session logs
pi logs                               # Pi session logs
```

### Common failures

| Symptom | Cause | Fix |
|---------|-------|-----|
| Extension not in `omp list` | Path wrong or not in `config.yml` | Verify path, run `chezmoi apply` |
| Extension listed but commands missing | Missing `plugin.json` or wrong dir layout | Add manifest or restructure |
| `getModel` not found | OMP API shim gap | See broken list in `config.local.yml` |
| Skills load in Pi but not OMP | `~/.omp/agent/skills` symlink broken | `ls -la ~/.omp/agent/skills` |
| Slash commands missing in OMP | `commands/` mirror absent or symlinks broken | `ls -la commands/` — each entry should resolve to `../prompts/<name>.md`; recreate with `ln -s` |

## Applying Config Changes

```bash
# Edit the chezmoi source
# For Pi:  ~/.local/share/chezmoi/dot_pi/agent/settings.local.jsonc
# For OMP: ~/.local/share/chezmoi/dot_omp/private_agent/config.local.yml

chezmoi apply                          # Deploy config changes
pi update --extensions                 # Reload Pi packages
omp update                             # Reload OMP plugins
```

Restart the agent after updating for changes to take effect.

## See also

- `skills/cross-platform-pi-omp-loading/SKILL.md` — package authoring pattern for shipping one package that works in both runtimes (manifest keys, directory layout, OMP API shim gaps).
- `skills/cross-platform-pi-omp-loading/slash-command-mirror/SKILL.md` — the `prompts/` ↔ `commands/` symlink pattern in depth, including the per-file vs single-directory trade-off and drift mitigation.

## Multi-Harness Installer (`buck-workflow install`)

The installer (`scripts/install.mjs`) handles the **external fan-out** that the package system cannot: symlinking bootstrap instructions and skill/command trees into harness directories that don't use Pi or OMP's package loading.

### How it relates to package loading

For **Pi and OMP**, the installer symlinks **bootstrap only** (`GLOBAL_OR_PROJECT-AGENTS.md` → harness AGENTS.md). Skills and commands are already loaded by the package system (`pi install` / OMP auto-discovery). Duplicating them via installer symlinks would cause double-loading.

For **Claude Code** and **OpenCode**, the installer symlinks bootstrap +
commands + skills because these harnesses do not use Pi/OMP's package system.
For **Codex**, it symlinks bootstrap instructions only; Buck Workflow skills
are installed from this repository's Codex plugin marketplace.

**Cursor** is project-scoped only — the installer detects it but does not create global symlinks.

### Idempotency

The installer is idempotent: re-running it skips symlinks that already point to the correct target, replaces stale ones, and warns about conflicts (real files at the destination). Use `--force` to overwrite conflicts. This makes `git pull && buck-workflow install` safe as a sync workflow.

### Chezmoi interaction

If harness config files are managed by chezmoi, they'll appear as real files (not symlinks). The installer detects this and reports a conflict rather than clobbering. Use `--force` to replace, or manage the symlink through chezmoi's `dot_*` source files instead.
