# How-to guides

Everyday tasks this project is set up for. Each how-to is numbered
steps, then **Eat** — the check that it worked.

## OMP commands

1. [Run the /code-review command](run-code-review.md)
2. [Prune retained /code-review runtime](prune-code-review-runtime.md)

## Why

- [Local-only isolated code-review loop](../adr/0001-local-only-isolated-code-review-loop.md)
