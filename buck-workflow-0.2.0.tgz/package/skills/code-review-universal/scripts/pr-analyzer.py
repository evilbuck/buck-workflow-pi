#!/usr/bin/env python3
"""
PR Analyzer - Analyze PR complexity and suggest review approach.

Usage:
    python pr-analyzer.py [--diff-file FILE] [--stats]

    Or pipe diff directly:
    git diff main...HEAD | python pr-analyzer.py
"""

import os
import sys
import re
import argparse
from collections import defaultdict
from dataclasses import dataclass
from typing import List, Dict, Optional

RISK_NO_TESTS = "NO_TEST_CHANGES"


@dataclass
class FileStats:
    """Statistics for a single file."""
    filename: str
    additions: int = 0
    deletions: int = 0
    is_test: bool = False
    is_config: bool = False
    language: str = "unknown"


@dataclass
class PRAnalysis:
    """Complete PR analysis results."""
    total_files: int
    total_additions: int
    total_deletions: int
    files: List[FileStats]
    complexity_score: float
    size_category: str
    estimated_review_time: int
    risk_factors: List[str]
    suggestions: List[str]


def detect_language(filename: str) -> str:
    """Detect programming language from filename."""
    _, ext = os.path.splitext(filename)
    extensions = {
        '.py': 'Python',
        '.js': 'JavaScript',
        '.ts': 'TypeScript',
        '.tsx': 'TypeScript/React',
        '.jsx': 'JavaScript/React',
        '.rs': 'Rust',
        '.go': 'Go',
        '.c': 'C',
        '.h': 'C/C++',
        '.cpp': 'C++',
        '.hpp': 'C++',
        '.cc': 'C++',
        '.cxx': 'C++',
        '.hh': 'C++',
        '.hxx': 'C++',
        '.java': 'Java',
        '.kt': 'Kotlin',
        '.swift': 'Swift',
        '.rb': 'Ruby',
        '.php': 'PHP',
        '.cs': 'C#',
        '.vue': 'Vue',
        '.svelte': 'Svelte',
        '.sql': 'SQL',
        '.md': 'Markdown',
        '.json': 'JSON',
        '.yaml': 'YAML',
        '.yml': 'YAML',
        '.toml': 'TOML',
        '.css': 'CSS',
        '.scss': 'SCSS',
        '.less': 'Less',
        '.html': 'HTML',
        '.zig': 'Zig',
        '.ex': 'Elixir',
        '.exs': 'Elixir',
        '.erl': 'Erlang',
        '.scala': 'Scala',
        '.lua': 'Lua',
    }
    return extensions.get(ext.lower(), 'unknown')


def is_test_file(filename: str) -> bool:
    """Check if file is a test file."""
    test_patterns = [
        r'(?:^|/)test_[^/]+\.py$',   # Python: test_handler.py (anchored to path segment)
        r'[^/]+_test\.',             # *_test.<ext> — Rust, Go, etc.
        r'[^/]+\.test\.(js|ts|tsx|jsx)$',  # JS/TS: handler.test.ts
        r'[^/]+\.spec\.(js|ts|tsx|jsx)$',  # JS/TS: handler.spec.ts
        r'(?:^|/)tests?/',           # tests/ or test/ directory
        r'(?:^|/)__tests__/',        # __tests__/ directory
        r'(?:^|/)spec/',             # spec/ directory (Ruby, etc.)
    ]
    return any(re.search(p, filename) for p in test_patterns)


def is_config_file(filename: str) -> bool:
    """Check if file is a configuration file.

    Uses explicit known-name matching to avoid flagging data files
    like data.json, openapi.yaml, or swagger.json as config.
    """
    basename = os.path.basename(filename)

    # Env files (.env, .env.local, .env.production, …)
    if basename.startswith('.env'):
        return True

    # Known config filenames (exact match)
    known_config_names = {
        'package.json', 'package-lock.json',
        'tsconfig.json', 'jsconfig.json',
        'babel.config.json', 'babel.config.js',
        'webpack.config.js', 'webpack.config.ts',
        'rollup.config.js', 'vite.config.ts', 'vite.config.js',
        '.eslintrc.json', '.eslintrc.js', '.eslintrc.yml',
        '.prettierrc.json', '.prettierrc.yml', '.prettierrc.js',
        'jest.config.js', 'jest.config.ts',
        'vitest.config.ts', 'vitest.config.js',
        'tailwind.config.js', 'tailwind.config.ts',
        'postcss.config.js',
        'docker-compose.yml', 'docker-compose.yaml',
        'Dockerfile',
        'Makefile', 'CMakeLists.txt',
        'pyproject.toml', 'poetry.toml', 'Pipfile',
        'setup.cfg', 'setup.py', 'tox.ini',
        'Cargo.toml', 'Cargo.lock',
        'go.mod', 'go.sum',
        'Gemfile', 'Gemfile.lock',
        'composer.json', 'composer.lock',
        'Podfile', 'Package.swift',
        '.gitignore', '.gitattributes',
        'gradle.properties', 'build.gradle', 'build.gradle.kts',
        'settings.gradle', 'settings.gradle.kts',
    }
    if basename in known_config_names:
        return True

    # Known config path patterns
    config_path_patterns = [
        r'\.github/workflows/[^/]+\.ya?ml$',
        r'\.vscode/',
        r'\.idea/',
    ]
    if any(re.search(p, filename) for p in config_path_patterns):
        return True

    # Files with "config" in the name (e.g. app.config.ts, database_config.yml)
    if re.search(r'config\.', basename):
        return True

    # Files under a config/ directory
    if re.search(r'(?:^|/)config/', filename):
        return True

    return False


# Path-prefix handling for the `+++` and `---` lines. Prefixes vary
# with git config: a//b/ default, c//i//w//o/ under
# diff.mnemonicprefix, nothing under diff.noprefix. Git C-quotes paths
# containing spaces or special characters, so unquote before stripping.
_PATH_UNQUOTE_RE = re.compile(r'\\(.)')


def _strip_diff_path_prefix(raw: str, header_prefixed: bool) -> str:
    """Strip a `+++`/`---` diff path's optional prefix and C-quoting.

    `header_prefixed` MUST reflect the diff style observed at the
    matching `diff --git` header (True under default a//b/ and
    diff.mnemonicprefix, False under diff.noprefix). We cannot infer
    it from a single path: `s/x.py` under noprefix is a literal
    one-letter directory and must NOT be stripped to `x.py`.

    Examples:
      `b/lib/foo.py`,    prefixed=True   -> `lib/foo.py`
      `w/src/main.py`,   prefixed=True   -> `src/main.py`
      `src/x.py`,        prefixed=False  -> `src/x.py`
      `s/x.py`,          prefixed=False  -> `s/x.py`   (one-letter dir!)
      `"a/b c/d.py"`,    prefixed=True   -> `a/b c/d.py`  (spaces, quoted)
    """
    s = raw.strip()
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        s = _PATH_UNQUOTE_RE.sub(r'\1', s[1:-1])
    if header_prefixed:
        m = re.match(r'^[a-z]/(.+)$', s)
        if m:
            return m.group(1)
    return s


def parse_diff(diff_content: str) -> List[FileStats]:
    """Parse git diff output and extract file statistics."""
    files = []
    current_file = None

    # Pending file state: collected between a `diff --git` header and
    # the first authoritative path line (`rename to` for renames,
    # `+++`/`---` for add/modify/delete). The diff header line itself
    # is NOT used to extract the path because prefixes vary (a//b/
    # default, c//i//w//o/ under diff.mnemonicprefix, nothing under
    # diff.noprefix) and renames have different src/dst. The header
    # IS used to detect whether the diff is prefix-styled — that
    # answer is needed when stripping the prefix from the `+++`/`---`
    # line so noprefix paths like `s/x.py` aren't mistaken for
    # prefixed `s/x.py` and stripped to `x.py`.
    pending_path = None     # the authoritative path once known
    header_prefixed = False # does the diff style include a letter prefix?
    saw_diff_header = False # between header and `+++`/`---`
    old_path = None         # persists across `---` -> `+++` within one file
    for line in diff_content.split('\n'):
        if line.startswith('diff --git'):
            # Close out the previous file (if any).
            if current_file:
                files.append(current_file)
            # Detect prefix style from the header: prefix-styled diffs
            # always show two DIFFERENT letter-prefixed tokens on the
            # `diff --git` line (a/foo b/foo, c/foo w/foo, i/foo w/foo,
            # etc.). Under diff.noprefix both tokens are identical bare
            # paths. The per-token letter+slash shape alone is
            # insufficient — noprefix `s/x.py s/x.py` would otherwise
            # be mistaken for a prefix style. We use the inequality of
            # the two tokens as the signal; this is robust against
            # any single-letter config letter.
            rest = line[len('diff --git '):].strip()
            parts = rest.split(' ', 1)
            if len(parts) == 2:
                src_token, dst_token = parts
                header_prefixed = src_token != dst_token
            else:
                header_prefixed = False
            current_file = None
            pending_path = None
            old_path = None
            saw_diff_header = True
            # Best-effort same-path fallback: when the two header
            # tokens refer to the SAME underlying path, extract it
            # right now so the file is tracked even when no
            # `---`/`+++`/`rename to` ever arrives. This covers
            # modify entries (where the authoritative `+++` line
            # will still arrive and override this), and critically
            # binary / chmod-only entries that never produce body
            # lines. The `+++` / `rename to` handlers below will
            # override this by re-issuing `current_file =
            # FileStats(...)` — they replace the fallback entry
            # when they fire.
            #
            # Try prefix-styled same-path first
            # (`a/foo b/foo`, `c/foo w/foo`), then noprefix same-token
            # (`foo foo` / `s/x.py s/x.py`).
            if len(parts) == 2:
                joined = parts[0] + ' ' + parts[1]
                m = re.match(r'^[a-z]/(.+?) [a-z]/\1$', joined)
                if m:
                    fallback_path = m.group(1)
                    current_file = FileStats(
                        filename=fallback_path,
                        language=detect_language(fallback_path),
                        is_test=is_test_file(fallback_path),
                        is_config=is_config_file(fallback_path),
                    )
                elif parts[0] == parts[1]:
                    # noprefix: tokens are identical. Pull the path
                    # off either token — but only the first, since
                    # `s/x.py` is one path, not two.
                    fallback_path = parts[0]
                    current_file = FileStats(
                        filename=fallback_path,
                        language=detect_language(fallback_path),
                        is_test=is_test_file(fallback_path),
                        is_config=is_config_file(fallback_path),
                    )
            continue
        if saw_diff_header and line.startswith('rename to '):
            # `rename to <path>` is the authoritative destination for
            # rename entries; it never has a prefix. Commit immediately.
            pending_path = line[len('rename to '):].strip()
            current_file = FileStats(
                filename=pending_path,
                language=detect_language(pending_path),
                is_test=is_test_file(pending_path),
                is_config=is_config_file(pending_path),
            )
            saw_diff_header = False
            continue
        if saw_diff_header and line.startswith('rename from '):
            # Source side of a rename; keep awaiting `rename to`.
            continue
        if saw_diff_header and line.startswith('--- '):
            # Unified diff order is `--- old` then `+++ new`. Record
            # the old path; we'll commit it (after prefix stripping)
            # when the matching `+++` arrives, unless `+++` is
            # `/dev/null` (deletion), in which case the old path IS
            # the file's identity.
            raw = line[4:].strip()
            if raw != '/dev/null':
                old_path = _strip_diff_path_prefix(raw, header_prefixed)
            else:
                old_path = None
            continue
        if saw_diff_header and line.startswith('+++ '):
            # `+++ <path>` is the authoritative destination for
            # add/modify entries. `+++ /dev/null` means the file was
            # deleted; use the previously-recorded `old_path`.
            raw = line[4:].strip()
            if raw == '/dev/null':
                if old_path:
                    pending_path = old_path
                else:
                    # No prior `---` (shouldn't happen in well-formed
                    # diffs); fall back to the dst side of the
                    # `diff --git` header. Strip prefix by hand.
                    rest = line[len('diff --git '):].strip()
                    # We can't reconstruct here — just skip.
                    saw_diff_header = False
                    continue
            else:
                pending_path = _strip_diff_path_prefix(raw, header_prefixed)
            current_file = FileStats(
                filename=pending_path,
                language=detect_language(pending_path),
                is_test=is_test_file(pending_path),
                is_config=is_config_file(pending_path),
            )
            saw_diff_header = False
            continue
        if saw_diff_header:
            # Other intermediate lines (index, mode, similarity, etc.)
            # don't identify the file. Keep waiting.
            continue
        if current_file:
            if line.startswith('+') and not line.startswith('+++'):
                current_file.additions += 1
            elif line.startswith('-') and not line.startswith('---'):
                current_file.deletions += 1

    if current_file:
        files.append(current_file)

    return files


def calculate_complexity(files: List[FileStats]) -> float:
    """Calculate complexity score (0-1 scale)."""
    if not files:
        return 0.0

    total_changes = sum(f.additions + f.deletions for f in files)

    # Base complexity from size
    size_factor = min(total_changes / 1000, 1.0)

    # Factor for number of files
    file_factor = min(len(files) / 20, 1.0)

    # Factor for non-test code ratio
    test_lines = sum(f.additions + f.deletions for f in files if f.is_test)
    non_test_ratio = 1 - (test_lines / max(total_changes, 1))

    # Factor for language diversity
    languages = set(f.language for f in files if f.language != 'unknown')
    lang_factor = min(len(languages) / 5, 1.0)

    complexity = (
        size_factor * 0.4 +
        file_factor * 0.2 +
        non_test_ratio * 0.2 +
        lang_factor * 0.2
    )

    return round(complexity, 2)


def categorize_size(total_changes: int) -> str:
    """Categorize PR size."""
    if total_changes < 50:
        return "XS (Extra Small)"
    elif total_changes < 200:
        return "S (Small)"
    elif total_changes < 400:
        return "M (Medium)"
    elif total_changes < 800:
        return "L (Large)"
    else:
        return "XL (Extra Large) - Consider splitting"


def estimate_review_time(files: List[FileStats], complexity: float) -> int:
    """Estimate review time in minutes."""
    total_changes = sum(f.additions + f.deletions for f in files)

    # Base time: ~1 minute per 20 lines
    base_time = total_changes / 20

    # Adjust for complexity
    adjusted_time = base_time * (1 + complexity)

    # Minimum 5 minutes, maximum 120 minutes
    return max(5, min(120, int(adjusted_time)))


def identify_risk_factors(files: List[FileStats]) -> List[str]:
    """Identify potential risk factors in the PR."""
    risks = []

    total_changes = sum(f.additions + f.deletions for f in files)
    test_changes = sum(f.additions + f.deletions for f in files if f.is_test)

    if total_changes > 400:
        risks.append("Large PR (>400 lines) - harder to review thoroughly")

    if test_changes == 0 and total_changes > 50:
        risks.append(f"{RISK_NO_TESTS}: No test changes - verify test coverage")

    if total_changes > 100 and test_changes / max(total_changes, 1) < 0.2:
        risks.append("Low test ratio (<20%) - consider adding more tests")

    # Security-sensitive files
    security_patterns = ['.env', 'auth', 'security', 'password', 'token', 'secret']
    for f in files:
        if any(p in f.filename.lower() for p in security_patterns):
            risks.append(f"Security-sensitive file: {f.filename}")
            break

    # Database changes
    for f in files:
        if 'migration' in f.filename.lower() or f.language == 'SQL':
            risks.append("Database changes detected - review carefully")
            break

    # Config changes
    config_files = [f for f in files if f.is_config]
    if config_files:
        risks.append(f"Configuration changes in {len(config_files)} file(s)")

    return risks


def generate_suggestions(files: List[FileStats], complexity: float, risks: List[str]) -> List[str]:
    """Generate review suggestions."""
    suggestions = []

    total_changes = sum(f.additions + f.deletions for f in files)

    if total_changes > 800:
        suggestions.append("Consider splitting this PR into smaller, focused changes")

    if complexity > 0.7:
        suggestions.append("High complexity - allocate extra review time")
        suggestions.append("Consider pair reviewing for critical sections")

    if any(RISK_NO_TESTS in r for r in risks):
        suggestions.append("Request test additions before approval")

    # Language-specific suggestions
    languages = set(f.language for f in files)
    if 'TypeScript' in languages or 'TypeScript/React' in languages:
        suggestions.append("Check for proper type usage (avoid 'any')")
    if 'Rust' in languages:
        suggestions.append("Check for unwrap() usage and error handling")
    if 'C' in languages or 'C++' in languages or 'C/C++' in languages:
        suggestions.append("Check for memory safety, bounds checks, and UB risks")
    if 'SQL' in languages:
        suggestions.append("Review for SQL injection and query performance")

    if not suggestions:
        suggestions.append("Standard review process should suffice")

    return suggestions


def analyze_pr(diff_content: str) -> PRAnalysis:
    """Perform complete PR analysis."""
    files = parse_diff(diff_content)

    total_additions = sum(f.additions for f in files)
    total_deletions = sum(f.deletions for f in files)
    total_changes = total_additions + total_deletions

    complexity = calculate_complexity(files)
    risks = identify_risk_factors(files)
    suggestions = generate_suggestions(files, complexity, risks)

    return PRAnalysis(
        total_files=len(files),
        total_additions=total_additions,
        total_deletions=total_deletions,
        files=files,
        complexity_score=complexity,
        size_category=categorize_size(total_changes),
        estimated_review_time=estimate_review_time(files, complexity),
        risk_factors=risks,
        suggestions=suggestions,
    )


def print_analysis(analysis: PRAnalysis, show_files: bool = False):
    """Print analysis results."""
    print("\n" + "=" * 60)
    print("PR ANALYSIS REPORT")
    print("=" * 60)

    print(f"\n📊 SUMMARY")
    print(f"   Files changed: {analysis.total_files}")
    print(f"   Additions: +{analysis.total_additions}")
    print(f"   Deletions: -{analysis.total_deletions}")
    print(f"   Total changes: {analysis.total_additions + analysis.total_deletions}")

    print(f"\n📏 SIZE: {analysis.size_category}")
    print(f"   Complexity score: {analysis.complexity_score}/1.0")
    print(f"   Estimated review time: ~{analysis.estimated_review_time} minutes")

    if analysis.risk_factors:
        print(f"\n⚠️  RISK FACTORS:")
        for risk in analysis.risk_factors:
            print(f"   • {risk}")

    print(f"\n💡 SUGGESTIONS:")
    for suggestion in analysis.suggestions:
        print(f"   • {suggestion}")

    if show_files:
        print(f"\n📁 FILES:")
        # Group by language
        by_lang: Dict[str, List[FileStats]] = defaultdict(list)
        for f in analysis.files:
            by_lang[f.language].append(f)

        for lang, lang_files in sorted(by_lang.items()):
            print(f"\n   [{lang}]")
            for f in lang_files:
                prefix = "🧪" if f.is_test else "⚙️" if f.is_config else "📄"
                print(f"   {prefix} {f.filename} (+{f.additions}/-{f.deletions})")

    print("\n" + "=" * 60)


def main():
    parser = argparse.ArgumentParser(description='Analyze PR complexity')
    parser.add_argument('--diff-file', '-f', help='Path to diff file')
    parser.add_argument('--stats', '-s', action='store_true', help='Show file details')
    args = parser.parse_args()

    # Read diff from file or stdin
    try:
        if args.diff_file:
            with open(args.diff_file, 'r', encoding='utf-8', errors='replace') as f:
                diff_content = f.read()
        elif not sys.stdin.isatty():
            diff_content = sys.stdin.buffer.read().decode('utf-8', errors='replace')
        else:
            print("Usage: git diff main...HEAD | python pr-analyzer.py")
            print("       python pr-analyzer.py -f diff.txt")
            sys.exit(1)
    except OSError as e:
        print(f"Error reading diff input: {e}", file=sys.stderr)
        sys.exit(1)

    if not diff_content.strip():
        print("No diff content provided")
        sys.exit(1)

    analysis = analyze_pr(diff_content)
    print_analysis(analysis, show_files=args.stats)


if __name__ == '__main__':
    main()
