# Middle Man

## Category

Couplers

## Signs and Symptoms

If a class performs only one action, delegating work to another class, why does it exist at all?

## Reasons for the Problem

This smell can be the result of overzealous elimination of [Message Chains](/refactoring/smells/message-chains).

In other cases, it can be the result of the useful work of a class being gradually moved to other classes. The class remains as an empty shell that doesn't do anything other than delegate.

## Treatment

- If most of a method's classes delegate to another class, [Remove Middle Man](/refactoring/remove-middle-man) is in order.

## Payoff

- Less bulky code.

## When to Ignore

Don't delete middle men that have been created for a reason:

- A middle man may have been added to avoid interclass dependencies.
- Some design patterns create middle men on purpose (such as [Proxy](/refactoring/design-patterns/proxy) or [Decorator](/refactoring/design-patterns/decorator)).

---

Source: https://refactoring.guru/smells/middle-man
