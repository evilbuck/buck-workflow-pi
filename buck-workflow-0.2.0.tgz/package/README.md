# Buck Workflow

A structured, discoverable workflow for AI-assisted software development with durable context management.

## Philosophy

The Buck workflow is built on one principle: **don't lose work**. It separates **intent** (plans in subject folders) from **record** (history in memory), creating a durable paper trail that survives chat context limits.

## Not a Framework — A Toolkit

Buck workflow is **not prescriptive**. You don't have to run it from start to finish. Each stage is a named thinking mode — pick the ones your task needs and skip the rest:

- **Start in the middle.** Already know what to build? Run `/b-plan` and skip the exploration.
- **Finish early.** Small change? `/b-build` → `/b-review` and you're done.
- **Ad-hoc.** Work freeform and let the global AGENTS.md baseline handle durability.

The global baseline ensures that even without running any Buck command, the agent still creates durable artifacts (memory, backlog updates, subject folders). Buck stages add structure on top; they don't gate basic durability.

## Architecture: Global Baseline + Buck Package + Project Config

Buck workflow is a stack of three layers that work together. The global layer is always active — it provides the durable-artifact conventions that make everything else work. Buck adds structured workflow stages. Project config adds domain-specific instructions.

### The Global Baseline (`~/.omp/agent/AGENTS.md` or `~/.pi/agent/AGENTS.md`)
The global AGENTS.md is loaded for every session, in every project. It establishes the conventions that make Buck work without requiring any Buck command to be run:

- **Before any task**: check `.context/memory/index.md` and recent memory files, check backlog
- **After any significant work**: write session memory, update the memory index, update backlog status
- **Artifact conventions**: subject folder structure, frontmatter format, cross-reference linking
- **Buck workflow surface**: `b-*` names as workflow labels that agents follow using `.context/` artifacts when native commands aren't available

This means **durability works even in quick ad-hoc sessions** where no Buck command is run. The baseline handles it automatically.

### Layer Ownership

| Layer | Location | Owns |
|-------|----------|------|
| **Global baseline** | `~/.omp/agent/AGENTS.md` or `~/.pi/agent/AGENTS.md` | Operating principles, durable-artifact principle, `.context/` conventions, Buck workflow surface |
| **Global reference** | Agent-global `docs/context-workflow.md` when installed | Detailed `.context/` conventions, frontmatter templates, backlog layout |
| **Buck package** | This repo | Workflow semantics, skills, prompt/command wrappers, minimal runtime automation |
| **Project config** | `./AGENTS.md` per repo | Build commands, code style, architecture notes, gotchas |

The global AGENTS.md is kept compact (~120 lines). Buck owns the detailed workflow taxonomy and runtime behavior. This means Buck workflow remains portable — the global layer provides a lightweight hint that points to Buck for non-trivial work.

## Install

> **For installing agents:** Read
> [`agent-install_instructions.md`](./agent-install_instructions.md) and
> **ask the user which harness they're on** (Pi, OMP, Codex, OpenCode,
> Claude Code, or Grok Build) before running any install commands.

### Standalone B-Plan

`b-plan` can be installed and used by itself as the planning subset of Buck
Workflow. At startup it checks the active harness's loader-native skill catalog
for `b-build`, `b-review`, and `b-save`:

| State | Active-session result | B-Plan behavior |
|---|---|---|
| `full` | All three resolve | Preserve the full subject, stitching, phasing, and handoff workflow |
| `partial` | One or two resolve | Write the plan through the mini workflow and name the missing companions |
| `standalone` | None resolve in an authoritative catalog | Write the plan and offer harness-specific installation |
| `unknown` | No reliable catalog/resolver exists | Write the plan and make installation guidance conditional |

The mini workflow still creates
`.context/YYYY-MM-DD.<subject>/index.md` and a complete `plan-*.md`; it does not
pretend to provide unavailable build, review, save, phasing, or commit stages.
A detected harness, Buck checkout, `.context/` directory, bootstrap file, or
package record does **not** prove the full workflow is loaded. After install or
repair, reload the agent and repeat the three-sentinel probe.

### 1. Install the Buck Workflow Skills

Pi:

```bash
pi install git:github.com/evilbuck/buck-workflow-pi
```

OMP:

```bash
omp install git:github.com/evilbuck/buck-workflow-pi
```

Claude Code and OpenCode use a durable clone plus harness-specific links.
Codex installs Buck Workflow from this repository's local marketplace:

```bash
git clone https://github.com/evilbuck/buck-workflow-pi ~/.local/share/buck-workflow-pi
codex plugin marketplace add ~/.local/share/buck-workflow-pi
```

Restart the Codex desktop app, then install **Buck Workflow** from the
**Personal** marketplace in the Plugins Directory. See
[`agent-install_instructions.md`](./agent-install_instructions.md#codex-developersopenai-comcodex)
for verification and update steps.

### 2. Wire Supported Harness Surfaces

The installer detects which agent harnesses are present and symlinks only the
surfaces declared for each harness. Run it **from a durable checkout** — every
symlink it creates resolves back to wherever the installer itself lives:

```bash
git clone https://github.com/evilbuck/buck-workflow-pi ~/.local/share/buck-workflow-pi
node ~/.local/share/buck-workflow-pi/scripts/install.mjs
```

Already have a clone (development)? Run it from there instead of cloning again:

```bash
node scripts/install.mjs
```

**What it does:**
- Detects installed harnesses (Pi, OMP, Claude Code, Codex, OpenCode, Cursor, Grok Build)
- Symlinks `GLOBAL_OR_PROJECT-AGENTS.md` as bootstrap instructions for each
- Symlinks `prompts/*.md` as slash commands for Claude Code, OpenCode
- Symlinks `skills/<name>/` directories for Claude Code, OpenCode
- Idempotent — re-run anytime, existing correct symlinks are skipped

**Check what you actually have:**

```bash
node scripts/install.mjs --verify
```

Read-only. Prints every managed destination that is not a symlink into this
checkout, a per-harness tally, and the number of distinct source roots in use.
Exits `1` when it finds a split, a copied bootstrap, or a dangling link — so it
works as a guard in a script.

**Rules:**
- Never run the installer from a package-manager cache (`npx`, `pnpm dlx`) or a
  temp dir — the symlinks would point into a directory that gets evicted.
- Never `cp` the bootstrap file. Copies stop tracking the repo and drift silently.
  A copied bootstrap is a real file, so a normal re-run *skips* it; `--force`
  converts it back to a symlink.
- Use one source checkout for every harness. The source defaults to the
  installer's own location, so running it from two checkouts moves harnesses
  between roots — the run warns and names both, and `--verify` reports the split.

**Flags:**

| Flag | Purpose |
|------|---------|
| `--dry-run` | Print planned symlinks, write nothing |
| `--force` | Replace real files at destination (e.g., chezmoi-managed configs) |
| `--source <path>` | Repo root symlinks resolve from (default: auto-detect) |
| `--harness <id,...>` | Wire only named harnesses (comma-separated) |
| `--list` | Print detected harnesses and exit |
| `--verify` | Report what each harness resolves to; write nothing (exit 1 on problems) |

**Per-harness behavior:**

| Harness | Bootstrap | Commands | Skills | Notes |
|---------|:---------:|:--------:|:------:|-------|
| **Pi** | ✅ symlink | ❌ (package) | ❌ (package) | Skills/commands loaded via `pi install` |
| **OMP** | ✅ symlink | ❌ (package) | ❌ (package) | Skills/commands loaded via package manifest |
| **Claude Code** | ✅ → `CLAUDE.md` | ✅ `~/.claude/commands/` | ✅ `~/.claude/skills/` | |
| **Codex** | ✅ → `AGENTS.md` | ❌ (no commands) | Plugin-managed | Install **Buck Workflow** from the repository marketplace; invoke skills with `$name` |
| **OpenCode** | ✅ → `AGENTS.md` | ✅ `~/.config/opencode/commands/` | ✅ `~/.config/opencode/skills/` | |
| **Cursor** | — | — | — | Project-scoped only (`.cursor/rules/`); no global install |
| **Grok Build** | ✅ → `~/.grok/rules/buck-workflow.md` | ✅ `~/.grok/commands/` | ✅ `~/.grok/skills/` | Native Grok surfaces; do not rely on Claude-compat |

**Bootstrap drift fix:** The installer uses symlinks instead of copies, so `git pull` + re-run keeps every harness in sync. No more manual re-copying when the bootstrap file changes.

#### Per-Project (Optional)

If you want project-specific instructions in addition to the global bootstrap, place an `AGENTS.md` in the project root:

```bash
cp GLOBAL_OR_PROJECT-AGENTS.md /path/to/your-project/AGENTS.md
```

Most agents load both global and project-level files — the project-level one extends the global baseline with build commands, code style, and architecture notes.

## What's Included

### Layered Architecture

1. **Canonical skills** (`skills/`) — Portable workflow logic. Agent-neutral Markdown files that define *how* each workflow behaves. These are the source of truth.
2. **Thin wrappers** (`prompts/` + `commands/`) — Agent-native invocation surface. Pi reads `prompts/*.md` as slash commands. OMP reads `commands/*.md`; those files are symlinks back to `prompts/` (eight real-file exceptions — see [OMP Command Mirror](#omp-command-mirror)) so there is one source of truth.
3. **Runtime automation** (`extensions/index.ts`) — Composed Pi/OMP extension surface: model auto-switch, TPS tracking, deterministic `*-improved` commands, opt-in plan-artifact bridge. Historical orchestration subsystems remain in `extensions/` but are not wired by the package manifest.

**Runtime mapping:**

- **Pi `/b-*` commands** → prompt templates in `prompts/` that invoke skills in `skills/`
- **OMP `/b-*` commands** → symlinks in `commands/` that point to the same prompt templates
- **Runtime hooks** → `extensions/index.ts` only: model auto-switch for phased plans, token-per-second tracking, deterministic `*-improved` commands, opt-in plan-artifact bridge
- **`/b-save`** → pure prompt + skill (`prompts/b-save.md`, `skills/b-save/SKILL.md`), not an extension command; run before `/b-commit` to record durable session state

### Cross-Agent Parallels

Skills are designed to be a portable layer. Each agent would invoke them through its native mechanism:

| Agent | Invocation Mechanism | Example | Installed by |
|-------|---------------------|---------|-------------|
| **Pi** | Prompt templates (`prompts/`) | `/b-plan` loads `prompts/b-plan.md` | `pi install` (package) |
| **OMP** | Command mirror (`commands/`) | `/b-plan` loads `commands/b-plan.md` → `../prompts/b-plan.md` | Package manifest |
| **Claude Code** | Commands (`.claude/commands/`) | `/b-plan` loads the same prompt template | `buck-workflow install` |
| **Codex** | Plugin skill invocation | `$b-plan` after installing Buck Workflow | Repository marketplace + Plugins Directory |
| **OpenCode** | Commands + skills | `/b-plan` loads the same prompt template | `buck-workflow install` |
| **Cursor** | Project rules (`.cursor/rules/`) | Rule file references skill content | Manual (project-scoped) |
| **Grok Build** | Skills + commands (`~/.grok/`) | `/b-plan` loads the same prompt template | `buck-workflow install --harness grok` |
| **Goose** | Summon skills | Load `b-init-factory` (or other `b-*` skills) by name | Manual (Summon); no installer surface |

Prompt templates are the source of truth for slash-command bodies. Skills, `.context/` conventions, and the global AGENTS.md are written to be agent-agnostic. The installer wires each harness's native loading mechanism to the shared source of truth.

**Want to help?** Pull requests that improve support for Claude Code, Cursor, OpenCode, Codex, or other agent harnesses are very welcome. The skills are plain Markdown — the main work is testing the full workflow on each harness and fixing any behavioral quirks.

### Prompt Templates (`/b-*` commands)

Type `/b-` in Pi or OMP to see the Buck workflow slash commands. Each prompt command is a thin wrapper that invokes the matching skill:

| Command | Skill Invoked | Purpose |
|---------|---------------|---------|
| `/b-brainstorm` | `b-brainstorm` | Interview-style intake, capture initial thinking |
| `/b-explore` | `b-explore` | Explore codebases, trace architecture, map data flows |
| `/b-fix-rebase-conflict` | `b-fix-rebase-conflict` | Resolve rebase/merge conflicts with context-aware semantic merges |
| `/b-eval-upstream-prs` | `b-eval-upstream-prs` | Evaluate a fork's upstream PRs — importance/friction/risk triage, isolated validation, merge-order plan (local-only) |
| `/b-init-guardrails` | `b-init-guardrails` | Initialize quality guardrails (lint, unit tests, functional tests, coverage, complexity) — one-shot, idempotent, brownfield-safe |
| `/b-init-factory` | `b-init-factory` | Initialize a nested agent software factory — factory-scoped AGENTS.md in a named folder, project default, or asked choice (never assume `.claude/`) |
| `/b-guardrails-check` | `b-guardrails-check` | Resolve the check contract by the resolution chain and run all gates; returns a structured verdict |
| `/b-research` | `b-research` | External/web research, source collection, evidence capture |
| `/b-capture` | `b-capture` | Note-taking mode — dump as we go via subagent; no polish until told |
| `/b-nasa-prd` | `b-nasa-prd` | Write or audit a PRD to NASA's requirement-quality standard (SEH Appendix C) |
| `/b-plan` | `b-plan` | Plan standalone or inside the full workflow; detect missing companions |
| `/b-plan-update` | `b-plan-update` | Apply new context, artifacts, and scope changes to an existing plan in place |
| `/b-phase` | `b-phase` | Break a large plan into sequential, independently-verifiable phases |
| `/b-present` | `b-present` | Generate async-readable presentation package |
| `/b-build` | `b-build` (standard mode) | Standard implementation — smallest safe code change |
| `/b-build-hard` | `b-build` (hard mode) | Complex, ambiguous, or higher-risk implementation |
| `/b-iterate` | `b-iterate` | Quick follow-up fixes, polish, review-loop edits |
| `/b-diagnose` | `b-diagnose` | Diagnose hard bugs/regressions — tight red-capable loop before any hypothesis |
| `/b-handoff` | `b-handoff` | Portable cross-harness/-directory/-machine handoff doc (OS temp dir, redacted secrets) |
| `/b-wizard` | `b-wizard` | Generate an interactive bash wizard for human-only setup steps (credentials, dashboards, cutovers) |
| `/b-init-tracker` | `b-init-tracker` | Configure this repo's issue tracker + triage labels (idempotent) |
| `/b-triage` | `b-triage` | Triage an inbound issue/PR — verify, grill if needed, write a behavioural agent brief |
| `/b-pr` | `b-pr` | Create a GitHub PR from the current feature branch — base resolution, rebase, diff-generated description |
| `/b-pr-review-2-issues` | `b-pr-review-2-issues` | PR review comments → classified, grouped plan artifact (no issues created) |
| `/b-review` | `b-review` | Review implementation for correctness and regressions |
| `/code-review` | `code-review` | Release-candidate PR review — parallel agents over high-risk areas, per-PR handoff files |
| `/code-review-universal` | `code-review-universal` | Universal PR review — one atomic severity-tagged GitHub review with inline comments |
| `/b-docs` | `b-docs` | Update living docs (conventions, decisions, language) when b-review flags impact |
| `/b-howto` | `b-howto` | Diátaxis how-to guides in `docs/howto/` — one action per file, numbered steps, last step Eat |
| `/b-recap` | `b-recap` | Summarize current session in one scan-friendly page (<500 words) — read-only orientation |
| `/b-commit` | `git-commit` | Create a Conventional Commits message and commit |

### OMP Command Mirror

Most `commands/*.md` are symlinks to `prompts/*.md`. They exist so OMP discovers the same slash commands that Pi exposes from `prompts/`.

**Exceptions** (real files, not symlinks): `b-pr.md`, `b-pr-review-2-issues.md`, `b-commit-improved.md`, and `b-save-improved.md` are thin skill-loader stubs whose `prompts/` twins carry full bodies; `b-kamal-release.md`, `b-pr-improved.md`, `git-clean-orphans.md`, and `product-tour.md` have no `prompts/` twin and are **OMP-only** slash commands. See [`docs/extension-loading.md`](docs/extension-loading.md#cross-platform-slash-command-pattern) for the heal procedure.

### Extension-Backed Commands

When the package extension is loaded (Pi/OMP), four commands run as deterministic code paths with live progress reporting instead of prompt-following:

| Command | Backing | Skill fallback |
|---------|---------|----------------|
| `/b-commit-improved` | `extensions/b-commit-improved/` | `git-commit-improved` skill |
| `/b-save-improved` | `extensions/b-save-improved/` | `b-save-improved` skill |
| `/b-pr-improved` | `extensions/b-pr-improved/` | `b-pr` skill |
| `/b-kamal-release` | `extensions/b-kamal-release/` | — |

### Pure Prompt Commands

| Command | Purpose |
|---------|---------|
| `/b-save` | Write `.context/memory` + backlog/index/cross-refs; on OMP, also `retain` session facts when tools exist; non-OMP agents optionally re-index via the configured Memory Search Tool |

### Skills

| Skill | Purpose |
|-------|---------|
| `b-brainstorm` | Interview-style intake — capture initial thinking and save a draft |
| `b-explore` | Explore unfamiliar codebases, trace architecture, map data flows |
| `b-arch-qa` | Live architecture Q&A session that builds a durable discussion doc (skill-only) |
| `b-fix-rebase-conflict` | Resolve large rebase/merge conflicts by reasoning over commit messages, diffs, and `.context/` artifacts |
| `b-init-guardrails` | One-shot, idempotent initialization of quality guardrails (lint, unit tests, functional tests, coverage, complexity) with a brownfield ratchet |
| `b-init-factory` | Nested agent software factory init — factory-scoped AGENTS.md + empty factory `docs/`; target is told, project default, or asked |
| `b-guardrails-check` | Resolve the check contract by the resolution chain and run all gates; returns a structured verdict. Measures only — never edits |
| `b-research` | Investigate external sources — APIs, libraries, documentation, web resources |
| `b-capture` | Note-taking mode — user dumps, subagent writes messy notes as-we-go; polish deferred until told |
| `crawl4ai` | Deep website crawling and content extraction (helper skill for b-research) |
| `b-nasa-prd` | NASA-standard PRD authoring and audit — shall/will/should, tolerances, traceable and verifiable requirements (bundled Appendix C source) |
| `b-plan` | Create a bounded plan standalone or within the full workflow; detect missing companions |
| `b-plan-update` | Update an existing plan in place — interweave additions, remove with review, revision log |
| `b-build` | Implement well-defined work (standard or hard mode) |
| `b-iterate` | Quick follow-up fixes, polish, review-loop edits |
| `b-diagnose` | Diagnosis loop for hard bugs/regressions — Phase 1 red-capable-loop gate, ranked falsifiable hypotheses, regression test at a correct seam |
| `codebase-design` | Deep-module design vocabulary (module/interface/depth/seam/adapter/leverage/locality), deletion test, design-it-twice fan-out (skill-only, no slash wrapper) |
| `b-handoff` | Portable seed doc for a different agent/harness/machine — writes to OS temp dir, suggested-skills section, redacts secrets |
| `writing-for-agents` | Reference for authoring skills/AGENTS.md/CLAUDE.md — context vs cognitive load, information hierarchy, completion criteria, leading words, no-op test, prompt-the-positive (skill-only, no slash wrapper) |
| `b-wizard` | Generates a bash wizard walking a human through credential/dashboard/cutover steps only they can perform; `template.sh` does the work |
| `b-init-tracker` | Configures docs/agents/issue-tracker.md + triage-labels.md and an idempotent AGENTS.md managed block (Sections A+B of the upstream setup skill; domain docs are b-docs' job) |
| `b-triage` | Redundancy/prior-rejection check → verify the claim → grill → durable behavioural agent brief (no file paths/line numbers) → produces the ready-for-agent state b-auto-fix consumes |
| `b-issue-create` | Turn the active plan/spec/research into an AFK-ready GitHub issue, linked back into `.context/` (skill-only) |
| `b-auto-fix` | Auto-fix a `ready-for-agent` GitHub issue via b-research → b-plan → b-build → b-review (skill-only) |
| `b-backlog` | Delegate backlog-item authoring + `todo.md` registration to a subagent (skill-only) |
| `b-review` | Review implementation for correctness and regressions |
| `b-docs` | Update living documentation (CONTEXT.md, docs/adr/, conventions block, docs/) from implementation |
| `b-howto` | Diátaxis how-to guides in `docs/howto/` — one action per file, numbered steps, last step Eat |
| `b-recap` | Summarize current session in one scan-friendly page (<500 words) — read-only orientation; does not replace `/b-save` |
| `b-save` | Session checkpoint to `.context/`; optional OMP `retain`/`learn` mirror; optional non-OMP memory-skill re-index |
| `b-memory-import` | Deterministic bulk import of `.context/memory/*.md` into OMP Hindsight (one-shot/backfill) |
| `b-hindsight-import-projects` | Multi-project wrapper over `b-memory-import` — bulk-import many projects' `.context/memory` in one pass (skill-only) |
| `b-present` | Generate async-readable presentation package from artifacts |
| `b-blueprint` | Single-page HTML architecture blueprint from plans/phases/brainstorms (skill-only) |
| `b-phase` | Analyze a plan and break it into sequential phases |
| `b-loop` | Set/change/clear the `omp_execution` autonomous loop on an existing phased plan — advisory + stamp only (skill-only) |
| `fix-pr` | Validate PR review comments against code; fix+push in-session or file issues (skill-only, no slash wrapper; OMP-first, agent-agnostic) |
| `b-pr` | Create a GitHub PR from the current feature branch — base resolution, auto-rebase, diff-generated description, `gh` create |
| `b-pr-review-2-issues` | Ingest PR comments → classify → group by theme (user-approved) → plan artifact; never creates issues |
| `code-review` | Release-candidate PR review — parallel agents over high-risk areas, per-PR handoff files |
| `git-commit` | Create a Conventional Commits message and commit |
| `git-commit-improved` | Deterministic Conventional Commits — code-driven counterpart (`/b-commit-improved` extension command) |
| `b-save-improved` | Deterministic session checkpoint — code-driven counterpart to `b-save` (`/b-save-improved` extension command) |
| `b-grill` | Stress-test a plan or design through structured interviewing |
| `b-grill-me` | Grill the user directly about a plan |
| `b-grill-auto` | Grill a different AI model via RPC about a plan |
| `b-grill-with-docs` | Grill against existing domain documentation |
| `run-in-idle-pane` | Detect least-active tmux pane and run commands there |
| `design-brief` | Extract UI design briefs from screenshots, files, text, and subject-folder context |
| `rails-app` | Rails project conventions and gotchas — subpath deployment, Tailwind build coupling, `assert_select` patterns, BEM theming |
| `code-review-universal` | Universal language-agnostic PR review — severity-tagged feedback, 23 language/framework reference guides (React/Vue/Angular/Rust/TS/Python/Go/etc.), cross-cutting patterns (security, performance, N+1, async), `scripts/pr-analyzer.py` for triaging large diffs, and GitHub PR reviews posted as one atomic review with inline comments (reuses `code-review` plumbing). Writes durable review reports to `.context/` |
| `b-create-styleguide` | Guided UX styleguide creation + idempotent maintenance, with a managed AGENTS.md/CLAUDE.md block |
| `b-create-ux-guide` | Site → component inventory → markdown style guide + HTML research guide + `design-brief.json` |
| `code-smells` | Reference catalog of the 23 code smells + parallel-subagent audit producing a remediation report |
| `cross-platform-pi-omp-loading` | Package-authoring pattern for shipping one package that loads under both Pi and OMP |
| `git-clean-orphans` | Inventory/remove stale worktrees and remote-gone branches; destructive steps gated on confirmation |
| `llm-wiki-vault` | Vault-native LLM Wiki for Obsidian PARA vaults — ingest, interlinked notes, knowledge-base maintenance |
| `manage-herdr-panes` | Split, start, prompt, and read Herdr panes (requires `HERDR_ENV=1`) |
| `node5-code-review` | Code review specialized for the node5 project |
| `pi-rpc` | Drive a `pi --mode rpc` subprocess via JSON RPC over stdio |
| `product-tour` | First-run guided product tours over real UI, stack-agnostic |
| `skill-explainer` | Explain a skill/command and produce a visual HTML walkthrough report |

### Extension (Runtime Hooks)

One manifest entry (`extensions/index.ts`) composes the wired surface:
- **Model auto-switch** for phased plans on `/b-build`, `/b-build-hard`, `/b-iterate`, and `/b-review`
- **Token-per-second tracking** during model generation
- **Deterministic commands**: `/b-pr-improved`, `/b-commit-improved`, `/b-save-improved`, `/b-kamal-release` (see [Extension-Backed Commands](#extension-backed-commands))
- **Plan-artifact bridge**: opt-in `turn_end` hook that persists an exited OMP plan-mode plan into the `.context/` subject-folder convention

Removed/unwired subsystems include `/b-mode`, plan-mode write guards, `/b-save` as an extension command, `b-flow`, `b-grill-auto` extension command wiring, tmux status, and session state injection. See [`docs/extension-loading.md`](docs/extension-loading.md) for the package loading truth table.

## Workflow Overview

Buck workflow is not a rigid pipeline. You choose which stages to run based on the task at hand:

### Full Workflow — New Feature

```
/b-brainstorm → /b-explore → /b-research → /b-plan → /b-build → /b-review → /b-docs → /b-save → /b-commit
```

Starting from a vague idea through to durable completion. Every artifact survives the session.
`/b-docs` is conditional — it runs only when `/b-review` flags documentation impact (new conventions, architecture decisions, or domain language). `/b-howto` is conditional the same way for user-facing how-tos. Most changes skip both. If both are flagged, `/b-docs` first (it follows `b-howto`); you do not have to invoke both.

### Partial Workflows

| Flow | When to Use |
|------|-------------|
| `/b-brainstorm → /b-plan → /b-build` | Idea to implementation in one session |
| `/b-plan → /b-build → /b-review → /b-docs → /b-save → /b-commit` | You already know what to build |
| `/b-research → /b-plan → /b-build-hard → /b-review → /b-docs → /b-save → /b-commit` | Complex/risky work |
| `/b-capture` → user says tidy → polish | Live notes; write first, clean later |
| `/b-fix-rebase-conflict → git rebase --continue → /b-review` | Large rebase/merge conflicts |
| `/b-build → /b-review` | Quick fix — no planning needed |
| `/b-iterate → /b-review` | Follow-up fix loop |
| `/skill:fix-pr <pr>` | Action PR review comments — validate, then fix+push or file issues (skill-only) |
| `/b-plan → /b-review → /b-docs → /b-save → /b-commit` | Plan and review without exploration |

### Ad-Hoc Work

You don't have to run any Buck command at all. The global AGENTS.md bootstrap (`~/.omp/agent/AGENTS.md` or `~/.pi/agent/AGENTS.md`) ensures that even in freeform sessions, the agent still writes memory, updates the backlog, and maintains `.context/` artifacts. Buck stages add structure; the baseline ensures continuity regardless.

## Subject Folder System

All artifacts are organized in dated subject folders:

```
.context/
├── 2026-04-08.auth-feature/
│   ├── research-oauth-providers.md
│   ├── plan-oauth-login.md
│   └── spec-v1-auth-mvp.md
├── backlog/
│   ├── todo.md
│   ├── items/<slug>.md
│   └── archive/
├── memory/
│   ├── index.md
│   └── auth-impl-2026-04-08.md
├── workflow/
│   └── current-session.json
└── backlog.md            # Legacy fallback (not used when backlog/ exists)
```

## Hybrid Context Indexes

Narrative `.context/` artifacts stay in Markdown. Machine query views are generated under `.context/index/`.

Commands:
```bash
npm run context:index
npm run context:validate
```

Generated files:

- `.context/index/subjects.json`
- `.context/index/memory.json`
- `.context/index/backlog.json`
- `.context/index/artifacts.json`

`context:validate` is strict on enum/value errors and currently reports legacy missing-field drift as warnings so older artifacts do not block adoption. `context:index` rebuilds the JSON views from Markdown source; never hand-edit the generated JSON.
## Cross-Reference System

Artifacts link to each other via frontmatter fields:

- **Research** → `informs: [plan-file.md]`
- **Plan** → `research: [research-file.md]`, `spec: spec-file.md`, `memory: []`
- **Spec** → `plans: [plan-file.md]`, `memory: []`
- **Memory** → `subject: YYYY-MM-DD.name`, `artifacts: [files...]`

`/b-save` stitches cross-references by executing the prompt/skill instructions directly.

## Requirements
- An AI coding agent — any supported harness (see [Compatibility](#compatibility))
- The `b-plan` skill for standalone planning, or the three sentinel companions
  (`b-build`, `b-review`, `b-save`) for the minimum full workflow
- A `.context/` directory in your project (created automatically on first use)
- For slash commands: Pi with `prompts/` loaded, OMP with the `commands/`
  mirror, or another harness with its native skill/command surface wired
- Optional: the bootstrap instructions for cross-session durability conventions
- Optional (OMP): `memory.backend: hindsight` or `mnemopi` so `/b-save` can `retain` and agents can `recall`/`reflect` prior work
- Optional (non-OMP agents): configure a memory search skill (e.g., [qmd](https://github.com/tobi/qmd)) in the project's `AGENTS.md` for local markdown search over `.context/memory`. OMP agents use native memory tools instead.

## Compatibility

**Buck workflow runs on all major agent harnesses.**

The multi-harness installer wires the surfaces declared for each detected
harness. Pi and OMP load skills through their package installers; Claude Code
and OpenCode receive skill/command links from the multi-harness installer;
Codex receives bootstrap instructions there and Buck Workflow skills through
the repository marketplace.
Pi and OMP are the maintained targets with full test coverage. Harnesses may
still differ in:

1. **Tool availability** — Some agents may not support all tools referenced by skills (e.g., `ast_grep`, `debug`)
2. **Schema compliance** — Frontmatter parsing and file conventions may vary
3. **Context injection** — How agents load and prioritize `AGENTS.md`/`CLAUDE.md` differs
4. **Cursor** — Global install not supported; requires project-scoped `.cursor/rules/` setup

### Contributing

Pull requests are welcome and encouraged:
- Bug fixes from testing on other harnesses
- Installer improvements and new harness support
- Documentation corrections

The skills are the portable core — if you can load a Markdown file and follow instructions, you can make Buck workflow run on any agent.


## License

MIT
